import sys
import os
import pandas as pd
import matplotlib.pyplot as plt

def visualize_memory(csv1, csv2=None):
    """Visualize memory usage from one or two Massif CSV files."""
    
    # Read the first CSV file
    df1 = pd.read_csv(csv1)
    label1 = os.path.splitext(os.path.basename(csv1))[0]

    plt.figure(figsize=(10, 6))

    if csv2:
        # If a second file is provided, plot both for comparison
        df2 = pd.read_csv(csv2)
        label2 = os.path.splitext(os.path.basename(csv2))[0]
        
        # Normalize time to a 0-100% scale for fair comparison
        global_min_time = min(df1['time'].min(), df2['time'].min())
        global_max_time = max(df1['time'].max(), df2['time'].max())
        time_range = global_max_time - global_min_time

        time1_normalized = (df1['time'] - global_min_time) / time_range * 100
        time2_normalized = (df2['time'] - global_min_time) / time_range * 100
        
        # Plot both datasets. Convert bytes to KB by dividing by 1024.
        plt.plot(time1_normalized, df1['heap'] / 1024, label=label1, color='orange', linewidth=2.5)
        plt.plot(time2_normalized, df2['heap'] / 1024, label=label2, color='blue', linewidth=2.5)
        plt.xlabel('Running percentage (%)')
    else:
        # Plot a single file
        plt.plot(df1['time'], df1['heap'] / 1024, label=label1, color='orange', linewidth=2.5)
        plt.xlabel('Time (ms)')
    
    # Style the plot
    plt.ylabel('Memory (KB)')
    plt.title('Memory Usage Over Time')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()

    # Save the plot
    output_filename = 'memory_usage_comparison.png'
    plt.savefig(output_filename)
    print(f"Graph successfully saved to '{output_filename}'")


if __name__ == "__main__":
    if len(sys.argv) == 3:
        csv_file1 = sys.argv[1]
        csv_file2 = sys.argv[2]
        visualize_memory(csv_file1, csv_file2)
    elif len(sys.argv) == 2:
        csv_file1 = sys.argv[1]
        visualize_memory(csv_file1)
    else:
        print("Usage: python3 visualize_memory.py <CSV file 1> [<CSV file 2>]")
